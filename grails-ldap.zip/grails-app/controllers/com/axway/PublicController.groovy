package com.axway

class PublicController {

    def index() { }
}
